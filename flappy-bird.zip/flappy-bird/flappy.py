import pygame
import sys
import random

# 遊戲常數設定
WIDTH = 400         # 視窗寬度
HEIGHT = 600        # 視窗高度
FPS = 60            # 每秒更新幀數

# 小鳥屬性設定
BIRD_WIDTH = 34     # 小鳥寬度
BIRD_HEIGHT = 24    # 小鳥高度
BIRD_X = 50         # 小鳥水平位置（固定）
GRAVITY = 0.5       # 重力加速度
FLAP_STRENGTH = -10 # 小鳥向上跳躍的速度

# 管道屬性設定
PIPE_WIDTH = 52     # 管道寬度
PIPE_GAP = 150      # 上下管道之間的縫隙高度
PIPE_VEL = 3        # 管道向左移動的速度
PIPE_INTERVAL = 1500  # 每隔多少毫秒產生一組新管道

# 讀取中文字體（請確保字體檔案存在）
FONT_PATH = "font/NotoSansTC-Regular.ttf"

def start_screen(screen, clock):
    """開始畫面，等待玩家按下空白鍵開始遊戲"""
    font_title = pygame.font.Font(FONT_PATH, 48)
    font_instruct = pygame.font.Font(FONT_PATH, 32)
    
    while True:
        screen.fill((135, 206, 250))  # 天空藍背景

        # 顯示標題與提示訊息
        title_text = font_title.render("Flappy Bird", True, (255, 255, 255))
        instruct_text = font_instruct.render("按空白鍵開始", True, (255, 255, 255))
        title_rect = title_text.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 50))
        instruct_rect = instruct_text.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 20))
        screen.blit(title_text, title_rect)
        screen.blit(instruct_text, instruct_rect)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    return

        pygame.display.flip()
        clock.tick(FPS)

def game_loop(screen, clock):
    """遊戲主要迴圈"""
    bird_y = HEIGHT // 2
    bird_vel = 0
    bird_rect = pygame.Rect(BIRD_X, bird_y, BIRD_WIDTH, BIRD_HEIGHT)

    pipes = []
    last_pipe_time = pygame.time.get_ticks()
    score = 0
    font = pygame.font.Font(FONT_PATH, 32)  # 使用中文字體
    game_over = False

    while True:
        clock.tick(FPS)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    if game_over:
                        return
                    else:
                        bird_vel = FLAP_STRENGTH

        if not game_over:
            bird_vel += GRAVITY
            bird_y += bird_vel
            bird_rect.y = int(bird_y)

            current_time = pygame.time.get_ticks()
            if current_time - last_pipe_time > PIPE_INTERVAL:
                last_pipe_time = current_time
                gap_y = random.randint(100, HEIGHT - 100 - PIPE_GAP)
                top_pipe = pygame.Rect(WIDTH, 0, PIPE_WIDTH, gap_y)
                bottom_pipe = pygame.Rect(WIDTH, gap_y + PIPE_GAP, PIPE_WIDTH, HEIGHT - gap_y - PIPE_GAP)
                pipes.append({'top': top_pipe, 'bottom': bottom_pipe, 'scored': False})

            for pipe in pipes:
                pipe['top'].x -= PIPE_VEL
                pipe['bottom'].x -= PIPE_VEL

            pipes = [pipe for pipe in pipes if pipe['top'].right > 0]

            for pipe in pipes:
                if bird_rect.colliderect(pipe['top']) or bird_rect.colliderect(pipe['bottom']):
                    game_over = True

            if bird_rect.top < 0 or bird_rect.bottom > HEIGHT:
                game_over = True

            for pipe in pipes:
                if pipe['top'].right < BIRD_X and not pipe['scored']:
                    score += 1
                    pipe['scored'] = True

        screen.fill((135, 206, 250))

        pygame.draw.rect(screen, (255, 255, 0), bird_rect)

        for pipe in pipes:
            pygame.draw.rect(screen, (34, 139, 34), pipe['top'])
            pygame.draw.rect(screen, (34, 139, 34), pipe['bottom'])

        score_text = font.render(f"分數: {score}", True, (255, 255, 255))
        screen.blit(score_text, (10, 10))

        if game_over:
            over_text = font.render("遊戲結束! 按空白鍵重新開始", True, (255, 0, 0))
            over_rect = over_text.get_rect(center=(WIDTH // 2, HEIGHT // 2))
            screen.blit(over_text, over_rect)

        pygame.display.flip()

def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Flappy Bird")
    clock = pygame.time.Clock()

    while True:
        start_screen(screen, clock)
        game_loop(screen, clock)

if __name__ == '__main__':
    main()